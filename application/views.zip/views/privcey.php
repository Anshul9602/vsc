<link href="<?php echo base_url(); ?>/assets/css/new.css" rel="stylesheet">


<div>
  <div class="case-study-title-sectio wf-section">
    <div>
      <div class="container case-study">
        <div>
          <h1 class="h1 center">Privacy Policy</h1>
        </div>
      </div>
    </div>
  </div>
  <div class="newsroom-content wf-section">
    <div>
      <div class="container" style="min-height:500px;">
        <div class="">
        </div>
      </div>
    </div>
  </div>
</div>